# ITQA

Group Member detail

204107U   Kumarage M.M.V.D.
204035V   Dharmasena P.L.G.K.P.
204228P   Weerakkodi W.H.T.A.
204243G   Gunarathna J.M.J.M.
204093U   Kariyapperuma K.A.S.D
205091U   Sadhoon M.I.A.
